int a[];
main(){ sizeof a; }
