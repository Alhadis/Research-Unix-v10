/usr/lib/eign 6
prefer.out
