/*
 *	Initializations
 */

#include "asd.h"

char *hextab = "0123456789abcdef";
char *instr = "Instructions";
