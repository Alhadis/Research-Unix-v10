#include <stddef.h>
#include <stdio.h>
#include "dist.h"

int
chkperm(int fd)
{
	return 1;
}
