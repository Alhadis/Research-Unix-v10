#include <stddef.h>
#include <stdio.h>
#include "dist.h"

int
main(int argc, char *argv[])
{
	prog = argv[0];
	scanq(0, 0);
	return 0;
}
