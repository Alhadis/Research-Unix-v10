extern int optind;
extern char *optarg;
