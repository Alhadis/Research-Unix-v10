#! /bin/sh -
cat /etc/whoami
