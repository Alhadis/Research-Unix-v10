#define	TTY_CHIRP	0x10
#define	TTY_ALARM	0x08
#define	RPTON		0x100
#define	RPTHAVECHR	0x200
#define	RPTLOOKUP	0x400
#define	RPTMASK		0x700
#define KBD_INIT_STATUS	0xfe	/* initial status of kbd, needed for selftest */
