/*
 * static char ID[] = "@(#) sdp1.h: 1.1 3/16/82";
 */

#undef ERROR
#undef SUCCESS
#define SDPERROR		(-1)
#define SDPSUCCESS		1
