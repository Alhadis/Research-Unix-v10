/*
 * static char ID[] = "@(#) define2.h: 1.1 3/16/82";
 */

/* number of digits in sequence number of address space file names */
#define	COUNT		6

#define FILEINIT	{589824,589824,589824}

#define STAXINIT	{10,20,30,512,1024}

/* suffix to address space names */
#define SUFFIX		"<>"
