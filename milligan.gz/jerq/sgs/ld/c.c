main()
{
	f();
}
