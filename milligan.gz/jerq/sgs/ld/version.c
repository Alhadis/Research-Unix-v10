static char ID[] = "@(#) version.c: 1.5 3/13/83";

char version[] = "1.5: 3/13/83";
