/*
 * static char ID_attrh[] = "@(#) attributes.h: 1.1 1/6/82";
 */

#define att_R 		0x1
#define att_W 		0x2
#define att_X 		0x4
#define att_I 		0x8
