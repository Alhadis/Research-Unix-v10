#define	HEX	0
#define	OCTAL	1
#define	DECIMAL	2


#define	TROUBLE	-1L
#define	MAXLEN	512

/*
 *	static char ID_defs[] = "@(#) defs.h: 1.2 1/20/82";
 */
