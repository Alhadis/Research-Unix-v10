/*
 * static char ID_boolh[] = "@(#) bool.h: 1.1 1/7/82";
 */

/*
 *	Boolean constants
 */

typedef char BOOL;		/* Boolean variable */

#define		TRUE     1	/* logical true */
#define		FALSE    0	/* logical false */
