/*
 * static char ID_sdp2h[] = "@(#) sdp2.h: 1.1 1/7/82";
 */

#include "sdpsrc/hd/define2.h"
