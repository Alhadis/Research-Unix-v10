/*
 *	static char *ID_pass0.h = "@(#) pass0.h: 1.5 12/1/83";
 */

#define TMPFILE0	"m32as0"
#define TMPFILE1	"m32as1"
#define TMPFILE2	"m32as2"
#define TMPFILE3	"m32as3"
#define TMPFILE4	"m32as4"
#define TMPFILE5	"m32as5"
#define TMPFILE6	"m32as6"
#define TMPFILE7	"m32as7"

#define TEMPLATE	"/m32as?XXXXX"
