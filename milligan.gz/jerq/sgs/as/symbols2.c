static char ID[] = "@(#) symbols2.c: 1.1 1/7/82";

#undef PASS1
#include "symbols.c"
