static char ID[] = "@(#) symbols1.c: 1.2 1/15/82";

#define PASS1 1
#include "symbols.c"
