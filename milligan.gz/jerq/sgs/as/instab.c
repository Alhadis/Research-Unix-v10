static char *ID = "@(#) instab.c: 1.2 2/4/82";
#include "systems.h"
#include "symbols.h"
#include <instab.h>
#include <parse.h>
instr instab[] = {
#include "ops.out"
0
};
