/* @(#) comm1.c: 1.1 12/22/83				*/

# include "mfile1.h"

# include "common"

