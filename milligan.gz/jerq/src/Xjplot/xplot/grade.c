#include "jplot.h"
#include <stdio.h>
#include <math.h>
void
grade(a)
double a;
{
	e1->grade = a;
}
