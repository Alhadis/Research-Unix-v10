char *
whoami(){
	return("jplot");
}
