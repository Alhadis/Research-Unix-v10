#include "jcom.h"
#include "jplot.h"
#include <stdio.h>
#include <math.h>
void
color(s)
char *s;
{}
