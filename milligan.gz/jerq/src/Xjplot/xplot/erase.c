#include "jcom.h"
#include "jplot.h"

void
erase()
{
	graphic(ERASE);
	cmd_sent();
}
