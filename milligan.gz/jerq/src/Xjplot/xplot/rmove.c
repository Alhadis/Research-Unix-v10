#include <stdio.h>
#include "jplot.h"
void
rmove (dx, dy)
double dx, dy;
{
	move(e1->copyx+dx, e1->copyy+dy);
}
