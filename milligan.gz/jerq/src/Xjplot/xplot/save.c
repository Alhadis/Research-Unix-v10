#include <stdio.h>
#include "jplot.h"

save(){
	e1++;
	pcopy(e1-1,e1);
}
