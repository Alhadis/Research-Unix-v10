/*	local.h	2.2	83/08/11	*/

#ifdef V7
#include "v7.local.h"
#endif

#ifdef CORY
#include "c.local.h"
#endif

#ifdef INGRES
#include "ing.local.h"
#endif

#ifdef V6
#include "v6.local.h"
#endif

#ifdef CC
#include "cc.local.h"
#endif

#ifdef V40
#include "40.local.h"
#endif
