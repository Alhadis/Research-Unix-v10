/*	rcv.h	2.3	83/08/11	*/

/*
 * Mail -- a mail program
 *
 * This file is included by normal files which want both
 * globals and declarations.
 */

#ifdef	pdp11
#include <whoami.h>
#endif
#include "def.h"
#include "glob.h"
