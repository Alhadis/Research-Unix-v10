extern char *strcat();
extern char *strcpy();
extern char *strncpy();
extern char *strchr();
extern char *strrchr();
extern int strlen();
extern int strcmp();
extern int strncmp();
