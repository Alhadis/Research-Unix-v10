/*
 * Just keep track of the date/sid of this version of Mail.
 * Load this file first to get a "total" Mail version.
 */
static	char	*SccsID = "@(#)UCB Mail Version 2.18 (5/19/83)";
char	*version = "2.18 5/19/83";
