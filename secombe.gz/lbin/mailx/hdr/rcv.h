#ident "@(#)rcv.h	1.3 'attmail mail(1) command'"
#ident	"@(#)mailx:hdr/rcv.h	1.2.1.1"
/*	Copyright (c) 1984 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#ident	"@(#)mailx:hdr/rcv.h	1.2"

/*
 * mailx -- a modified version of a University of California at Berkeley
 *	mail program
 *
 * This file is included by normal files which want both
 * globals and declarations.
 */

/*
 */

/* #define	USG	1			/* System V */
/* #define	USG_TTY	1			/* termio(7) */
#define V9	1

#include "def.h"
#include "glob.h"
