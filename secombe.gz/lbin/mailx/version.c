char *version="mailx version V10  5/7/91";
