/* imported (network specific) routine */
extern int netdial();
extern int netaccept();
extern void netrefuse();
extern ipcinfo *netlisten();
