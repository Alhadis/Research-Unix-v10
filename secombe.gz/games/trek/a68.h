        #define STRUCT struct
        #define CHAR char
        #define BOOL char
        #define REG register
        #define INT int
        #define REAL double
        #define UNSIGNED unsigned
        #define STRING char *
        #define PTR int *
        
        #define EXITSW break
        
        #define BEGIN {
        #define END }
        
        #define IF if(
        #define THEN ){
        #define ELSE } else {
        #define ELIF } else if (
        #define FI }
        
        #define EXITFOR break
        #define FOR for(
        #define WHILE while(
        #define DO ){
        #define OD }
        #define REP do{
        #define PER }while(
        #define DONE );
        #define LOOP for(;;){
        #define POOL }
        
        #define SKIP ;
        #define DIV /
        #define REM %
        #define NEQ ^
        #define ANDF &&
        #define ORF ||
        
        #define TRUE  (-1)
        #define FALSE 0
        #define LOBYTE 0377
        #define HIBYTE 0177400
        #define STRIP 0177
        #define HEXMSK 017
        
        #define SP ' '
        #define TB '\t'
        #define NL '\n'
        #define EOF 0
        #define maxint 32767
