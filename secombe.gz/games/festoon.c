/*	%W%	*/
#include <stdio.h>
#define R random()
#define T 0.125
#define CHOOSE(x) (x[R%(sizeof x / sizeof *x)])
#define EQ(a,b) (strcmp(a,b)==0)
#define LAST(x) (x[strlen(x)-1])
#define VOWEL(x) (x=='a'||x=='e'||x=='i'||x=='o'||x=='u')
#define N 8
typedef struct xyz { char *type; 
	union { struct xyz *x[N];
		char *s[N]; } list; } *X,XX;
typedef struct { char *number,*ending,*tense,*an,*unspec,*passive; } *E,EE;

X getxx(),verbal(),comp(),advp(),adjph(),adverb(),adjective(),prep(),vprep();
X np(),aux(),vp(),art(),modal(),perf(),prog(),nounal(),sent(),comma();
X adjval();
char *tense(),*number(),*prefix(),*root();

double makeup=.95;
static char *adjlist[] = {"concrete","abstract","procedural","real","ideal",
			"functional","prototype",
			"effective","capable","incremental",
			"perceived","associated","interdepartmental",
			"diverse","characteristic","worst-case",
			"qualitative","fully automatic","candidate",
			"consensual","consequential","conjectural",
			"constructive","initial","cooperative",
			"essential","methodological","requisite",
			"historical","situational","political",
			"prepared","material","defined","well defined",
			"organizational","projected","overall",
			"accepted","rejected","corresponding",
			"committed","environmental","typical","working","timely",
			"growing","unprecedented","new","renewed","fresh",
			"rapid","changing","careful","comprehensive","broad",
			"massive","huge","enormous",
			"evaluated","discresionary",
			"durable","beneficial",
			"maximal","tremendous","minimal",
			"on-site","standardized","standard",
			"powerful","natural","necessary",
			"reasonable","successful",
			"doubtful","dubious","certain",
			"unified","different","similar","utilitarian",
			"realizable","organizable","motivated",
			"topical","valuable","feasible",
			"intelligent","deliverable","nontrivial",
			"worthwhile","complicated",
			"organized","organizing","progressing",
			"schedulable","resourceful","commanding",
			"important","allocatable","temporal",
			"ponderable","understandable","comprehendable",
			"past","present","future",
			"obvious","considerable","finished","completed",
			"unique","abovementioned",
			"major","minor","tendentious","activating",
			"actual","added","adequate","affordable",
			"analyzable","additional","intuitive",
			"artificial","good","better",
			"worse","bad","basic","fundamental","brief",
			"general","very unique","extreme","most unique",
			"central","proximate","approximate","collected",
			"conductable","comtemplatable",
			"continuing","demonstrable","desirable",
			"correctable","foreseeable",
			"discontinued","early","beginning",
			"effectuated","elucidated","emotional",
			"enclosed","enthused","entire","exact",
			"experimental","fearful","final",
			"following","informative",
			"full","complete","indicated","authorized",
			"modularized","submodularized",
			"particular","preferred","satisfactory",
			"measurable","referenced","literal",
			"modified",
			"correct","prioritized","prolonged",
			"regrettable","apparent",
			"continued","subsequent","sufficient",
			"suggestive","true","ultimate","separate",
			"purposeful","regarded","resulting",
			"doubtful","evident","interesting","worthy",
			"uniform",
			"vital","viable",
			"worthwhile","alternative",
			"sophisticated","employed",
			"clear","lucid","simple","perspicuous",
			"incomplete","concerned"};

random() {
long lrand();
static short tab[31];
static short i;
i=(lrand()>>15) & 32767;
return tab[i%31]=32767-tab[i%31]^i;
}

X nomq(env) E env; {
X v=getxx();
v->type="-nomq";
if(EQ(env->number,"sing")) {
	if(EQ(tense(),"past"))v->list.s[0]="there was";
	else v->list.s[0]="there is";
	}
else {
	if(EQ(tense(),"past"))v->list.s[0]="there were";
	else v->list.s[0]="there are";
	}
if(prob(0.2))v->list.s[1]=" not";
return v;
}
X rel(env) E env; {
static char *c[] = {"that","which"};
X v=getxx();
v->type="-rel";
v->list.s[0]=CHOOSE(c);
return v;
}

X sent(env) E env; {
X sentv=getxx();
sentv->type="sent";
if(prob(0.09)) {
	env->unspec="";
	sentv->list.x[1]=np(env);
	sentv->list.x[3]=aux(env);
	sentv->list.x[4]=vp(env);
	sentv->list.x[0]=nomq(env);
	sentv->list.x[2]=rel(env);
	return sentv;
	}
sentv->list.x[0]=np(env);
sentv->list.x[1]=aux(env);
sentv->list.x[2]=vp(env);
return sentv;
}

X nomy(env) E env; {
X v=getxx();
v->type="-nomq";
v->list.s[0]="the fact that";
return v;
}

X np(env) E env; {
X npv=getxx();
EE nenv;
static EE empty;
npv->type="np";
if(prob(0.025)) {
	nenv=empty;
	npv->list.x[0]=nomy(&nenv);
	npv->list.x[1]=sent(&nenv);
	if(env->number==0)env->number="sing";
	return npv;
	}
npv->list.x[1]=nounal(env);
npv->list.x[0]=art(env);
return npv;
}

X aux(env) E env; {
X auxv=getxx();
int i=0;
auxv->type="aux";
if(env->tense==0)env->tense=env->ending=tense();
if(prob(0.25))auxv->list.x[i++]=modal(env);
if(prob(0.25))auxv->list.x[i++]=perf(env);
if(prob(0.25))auxv->list.x[i++]=prog(env);
return auxv;
}

X passive(env) E env; {
X v=getxx();
v->type="-passive";
if(env->tense==0)env->tense=env->ending=tense();
if(env->number==0)env->number=number();
if(EQ(env->ending,"modal"))v->list.s[0]="be";
else if(EQ(env->ending,"-en"))v->list.s[0]="been";
else if(EQ(env->ending,"-ing"))v->list.s[0]="being";
else {
	if(EQ(env->tense,"past"))
		v->list.s[0]=EQ(env->number,"sing")?"was":"were";
	else v->list.s[0]=EQ(env->number,"sing")?"is":"are";
	}
env->passive=env->ending="pass";
return v;
}

X passprep(env) E env; {
X v=getxx();
v->type="-passprep";
v->list.s[0]="by";
return v;
}

X vp(env) E env; {
X vpv=getxx();
int i=0;
vpv->type="vp";
if(prob(0.5))vpv->list.x[i++]=passive(env);
vpv->list.x[i++]=verbal(env);
vpv->list.x[i++]=comp(env);
if(prob(0.10))vpv->list.x[i++]=advp(env);
return vpv;
}

X art(env) E env; {
static char *aspecsg[] = {"the","the","the","the","the","this","this","that"};
static char *aspecpl[] = {"the","the","the","the","the","these","those"};
static char *aunssg[] = {"a","a","a","a","a","a","a","much","each","any"};
static char *aunspl[] = {"some","a few","a couple","several","many","all",
			"no",
			"an undue number of",
			"a number of"};
X artv=getxx();
artv->type="-art";
if(env->number==0)env->number=number();
if(env->unspec==0&&prob(0.33)) {
	if(EQ(env->number,"sing"))artv->list.s[0]=CHOOSE(aspecsg);
	else artv->list.s[0]=CHOOSE(aspecpl);
	}
else if(prob(0.50)||env->an&&EQ(env->number,"sing")) {
	if(EQ(env->number,"sing"))artv->list.s[0]=env->an?"a":CHOOSE(aunssg);
	else artv->list.s[0]=CHOOSE(aunspl);
	if(env->an&&EQ(artv->list.s[0],"all"))artv->list.s[0]="";
	}
else artv->list.s[0]="";
env->unspec=0;
if(env->an&&EQ(env->an,"an")&&EQ(artv->list.s[0],"a"))
	artv->list.s[0]="an";
env->an=0;
return artv;
}

X modal(env) E env; {
static char *pres[] = {"can","may","must","shall","will"};
static char *past[] = {"could","might","should","would"};
X modalv=getxx();
modalv->type="-modal";
if(env->tense==0)env->tense=env->ending=tense();
if(EQ(env->ending,"pres"))modalv->list.s[0]=CHOOSE(pres);
	else modalv->list.s[0]=CHOOSE(past);
env->ending="modal";
return modalv;
}

X perf(env) E env; {
X perfv=getxx();
perfv->type="-perf";
if(env->tense==0)env->tense=env->ending=tense();
if(env->number==0)env->number=number();
if(EQ(env->ending,"past")) {
	perfv->list.s[0]="had";
	}
else if(EQ(env->ending,"pres")) {
	if(EQ(env->number,"sing"))perfv->list.s[0]="had";
	else perfv->list.s[0]="have";
	}
else perfv->list.s[0]="have";
env->ending="-en";
return perfv;
}

X prog(env) E env; {
X progv=getxx();
progv->type="-prog";
if(env->tense==0)env->tense=env->ending=tense();
if(env->number==0)env->number=number();
if(EQ(env->ending,"pres")) {
	if(EQ(env->number,"sing"))progv->list.s[0]="is";
	else progv->list.s[0]="are";
	}
else if(EQ(env->ending,"past")) {
	if(EQ(env->number,"sing"))progv->list.s[0]="was";
	else progv->list.s[0]="were";
	}
else if(EQ(env->ending,"-en")) {
	progv->list.s[0]="been";
	}
else if(EQ(env->ending,"modal")) {
	progv->list.s[0]="be";
	}
env->ending="-ing";
return progv;
}

X verb(env) E env; {
/* they pres, he pres, they past, they perf, they prog, they pass */
static char *ends[][6] = {{"ate","ates","ated","ated","ating","ated"},
			{"en","ens","ened","ened","ening","ened"},
			{"esce","esces","esced","esced","escing","esced"},
			{"fy","fies","fied","fied","fying","fied"},
			{"ize","izes","ized","ized","izing","ized"}};
X verbv=getxx();
int i;
verbv->type="-verb";
if(env->tense==0)env->tense=env->ending=tense();
if(env->number==0)env->number=number();
if(0&&prob(0.1)&&EQ(env->tense,env->ending)) {
	if(EQ(env->number,"sing")) {
		if(EQ(env->tense,"pres"))verbv->list.s[0]="is";
		else verbv->list.s[0]="was";
		}
	else {
		if(EQ(env->tense,"pres"))verbv->list.s[0]="are";
		else verbv->list.s[0]="were";
		}
	}
else {
	verbv->list.s[0]=prefix(env);
	verbv->list.s[1]=root(env);
	if(EQ(env->ending,"pres")&&EQ(env->number,"sing"))i=1;
	else if(EQ(env->ending,"pres")||EQ(env->ending,"modal"))i=0;
	else if(EQ(env->ending,"past"))i=2;
	else if(EQ(env->ending,"-en"))i=3;
	else if(EQ(env->ending,"-ing"))i=4;
	else if(EQ(env->ending,"pass"))i=5;
	else i=0;
	verbv->list.s[2]=ends[R%(sizeof ends/sizeof *ends)][i];
	}
env->ending=0;
return verbv;
}

X noun(env) E env; {
static char *suff[] = {"ion","sion","tion","age","ness","ment","ure",
			"ity","iety","ty","ence","ency","ance",
			"ancy","tude","hood","ture","ate","art","ard",
			"ism","ine","stress","trix","ess",
			"dom","ship","eer","ster","ant","ent","ary",
			"ery","ory","ette","let","ling","ule","kin",
			"ar","or","ist",
			"fulness",
			"kin","cule","icle","y","ability","iosos"};
static char *wordy[] = {"final completion","final ending","final outcome",
			"adaptation","appearance","argument","circumstance",
			"confession","confidence","delimitation","dilution",
			"dissertation","distribution","duplication",
			"entertainment","equipment","evolution",
			"existence","expression","generation","impression",
			"integration","interaction","investment","judgment",
			"population","provision","solution","statement",
			"tradition","transmission",
			"final result","added increment","assistance",
			"beneficial assistance","mutual cooperation",
			"projection","future projection",
			"capability","conjecture","consensus of opinion",
			"general consensus","absence","deficiency",
			"inadequacy","insufficience","insufficiency",
			"growing importance","renewed emphasis",
			"renewed interest","changing behavior",
			"critical thinking","careful thinking",
			"comprehensive survey","high standard",
			"basic foundation","system testing",
			"serious discussion","serious concern",
			"organizational framework","prototype model",
			"uniform nomenclature","greater cooperation",
			"uniform consistency","early expectation",
			"standardization","great similarity",
			"shortage","presence","sufficiency",
			"consequent result","construct","disutility",
			"early beginning","emotional feeling","endeavor",
			"authorization","order of magnitude","preference",
			"impact","joint cooperation","joint partnership",
			"main essential","methodology","modification",
			"necessary requisite","past history","situation",
			"effectuation","clarification","new doubt",
			"policy","encouragement","preparation",
			"criterion","material","interest","acceptance",
			"rejection","publication","circulation",
			"protection","insurance",
			"assignment","identification",
			"submission","request",
			"guidance","correspondence","inclusion",
			"attachment","assumption",
			"recommendation","prescription","approval",
			"discretion","responsibility","relevance",
			"issuance","termination","total effect",
			"deleterious effect","consolidation",
			"aggregation","definiteness","commencement",
			"actual experience","experience",
			"combination","accord","filing",
			"idea","abstraction","method","procedure",
			"complaint","maintenance","finance","travel",
			"purchase","repair","routine",
			"development","cancellation",
			"partitioning","development effort",
			"project","automation","multilevel architecture",
			"multilevel heirarchy","data stream",
			"objective",
			"individual assignment","mode of operation",
			"clear community","attendant interest",
			"task division","well defined interfacing",
			"team report","meeting time","effective use",
			"friction",
			"major objective","ownership",
			"overall project time constraint",
			"functional division","requirements analysis",
			"code development","charter",
			"requirements definition","vertical division",
			"broad range","strong feeling",
			"considerable latitude","overall project constraint",
			"sufficient resource","assigned task","expectation",
			"critical aspect","clear understanding",
			"computing load","clean interfacing","natural basis",
			"team activity","team responsibility",
			"main function","predominant portion",
			"work plan","major breakpoint","work module",
			"achievable accuracy","supplementary work",
			"field version","internal establishment",
			"internal communication","development progress",
			"internal meeting","experience level",
			"high level autonomy","adherence",
			"feasibility demonstration","persistent problem",
			"internal objective","idea sharing",
			"improved performance","unfamiliar methodology",
			"new methodology","development experience",
			"module specification","good progress",
			"optimal number","natural division",
			"good relationship","cross attendance",
			"attendance","necessary communication",
			"evolving organization","basic principle",
			"complete revision","general information",
			"primary objective","load-carrying capacity",
			"necessary revision","major change",
			"clarified interpretation","subsequent attempt",
			"basic objective","full utilization",
			"practical consideration",
			"proportionate quantity","substantial change",
			"database design","unified framework",
			"customer service","strong interest",
			"unified description","necessary background information",
			"provisioning","physical coverage","general observation",
			"new technology","validity determination",
			"relation","regulation","verification",
			"impediment","portal","practice","premise",
			"basis","movement","question",
			"issue","input","output","observation",
			"input","output","input","output",
			"mechanization","function","evaluation",
			"result","further consideration","category",
			"performance indicator","early warning",
			"analysis purpose","measurement","replacement",
			"utilitarian purpose",
			"quota","proposed enhancement","enhancement",
			"interfacing","team organization","module",
			"guideline","continuing study",
			"required assistance","major advance",
			"proposal","hierarchy",
			"current view","refinement","activity",
			"external description","tight schedule pressure",
			"internal conflict","internal issue",
			"reasonable compromise","next phase",
			"goal","time constraint","constraint",
			"outcome","important outcome",
			"considerable experience","intelligent choice",
			"deliverable documentation","discussion",
			"timely delivery","design issue","large quantity",
			"general environment","protocol",
			"transitioning","modeling",
			"considerable difficulty","abstract interfacing",
			"data structure","consideration","difficulty",
			"statistical accuracy",
			"agenda","technique","reordering",
			"reauthorization","current proposal",
			"significant change","criteria","validation",
			"validity",
			"terminology","current understanding",
			"incorporation","staffing impact",
			"schedule impact","cost tradeoff",
			"system architecture",
			"adequate capacity","centralization",
			"current task","system deployment",
			"attendant uncertainty","process",
			"potential usefulness","proposed method",
			"basic assumption","anomaly",
			"available data","potential improvement",
			"registration","exemption","exception",
			"follow-up","service",
			"installation","construction","necessity",
			"occasion","instrumentation","disposal",
			"attractiveness",
			"convenience","sponsoring",
			"signification","meaningfulness",
			"significantness","individuality",
			"specification","determination","affirmation",
			"recruitment","supervision","management",
			"oversight","overview","environment",
			"effectation","circumvention","location",
			"execution","effectiveness","consciousness",
			"notation","confirmation","restriction",
			"organization","realization","actification",
			"activation","reification","beginning","conclusion",
			"ending","finishing","teamwork","motivation",
			"attitude","good attitude",
			"progress","milestone","deadline","schedule",
			"allocation","resource","command","concern",
			"time","time frame","reality",
			"behaviour","ability","advent","increment",
			"opportunity","accomplishment","aggregate",
			"analysis","totality","matter",
			"date","duration","centrality",
			"proximity","collection","elimintaion",
			"investigation","opinion","debate",
			"decision","benefit","difference","discontinuity",
			"fabrication","plan","chart","forecast",
			"simplicity","simplification","maximization",
			"minimization","direction",
			"agreement",
			"amount","quantity","quality","essence",
			"description","violation","purpose",
			"primary purpose","automatic control","redefinition",
			"uniform emphasis","study activity","work activity",
			"concept stage","concept activity",
			"possible potential","summarization","system function",
			"rationale","significant enhancement","diverse need",
			"diverse organization","comprehensive plan","interim",
			"functional overview","system configuration",
			"configuration","failure","quantitative result",
			"major obstacle","conception",
			"effectiveness","final evaluation",
			"interrelationship","functional requirement",
			"system philosophy","verbal interchange",
			"perceived inadequacy","primary emphasis",
			"intermingling","cooperation","partnership",
			"adjustment","application","implementation",
			"contact","mention","power",
			"nature","invention","importance",
			"ground","reason","permission","size",
			"report","documentation","priority",
			"pursuance","recurrance","resumption",
			"presupposition","continuance",
			"substantiation","success","action","truth",
			"past experience","greater acceptability",
			"organizational structure","clear distinction",
			"clear definition",
			"significant use","unmet need","centralized organization",
			"vague concept","negative impact","detrimental effect",
			"modularization","submodularization",
			"effect","consistancy",
			"inconsistancy","completion","utilization",
			"reference","doubt","evidence",
			"viewpoint",
			"actual fact",
			"true fact","underlying purpose","viable alternative"};
X nounv=getxx();
int i=0;
nounv->type="-noun";
if(env->number==0)env->number=number();
if(prob(makeup)) {
	if(prob(0.05)) {
		nounv->list.s[i++]=CHOOSE(adjlist);
		nounv->list.s[i++]="ness";
		}
	else nounv->list.s[i++]=CHOOSE(wordy);
	}
else {
	nounv->list.s[i++]=prefix(env);
	nounv->list.s[i++]=root(env);
	nounv->list.s[i++]=CHOOSE(suff);
	}
if(EQ(env->number,"plural")) {
	if(LAST(nounv->list.s[i-1])=='s')nounv->list.s[i]="es";
	else if(LAST(nounv->list.s[i-1])=='y')nounv->list.s[i]="ies";
	else nounv->list.s[i]="s";
	}
return nounv;
}

X nounal(env) E env; {
X nounalv=getxx();
int i=0;
X p;
nounalv->type="nounal";
if(prob(0.15)) {
	nounalv->list.x[i++]=adjval(env);
	}
nounalv->list.x[i++]=noun(env);
if(prob(0.15)) {
	nounalv->list.x[i++]=adjph(env);
	}
env->an="a";
for(p=nounalv; p->type[0]!='-'; p=p->list.x[0]);
for(i=0; p->list.s[i]; i++) {
	if(p->list.s[i][0]==0)continue;
	if(VOWEL(p->list.s[i][0])) {
		env->an="an";
		}
	break;
	}
return nounalv;
}

X adjval(env) E env; {
X adjvalv=getxx();
int i=0;
adjvalv->type="adjval";
if(prob(0.25)) {
	adjvalv->list.x[i++]=adverb(env);
	}
do {
	adjvalv->list.x[i++]=adjective(env);
	} while(i<N-1&&prob(0.25));
return adjvalv;
}

char *prefix(env) E env; {
static char *pref[] = {
"amb","ambi","super","hyper","an","tra","trans","post","palim",
"omni","pan","circ","circum","peri","a","ab","abs","de","apo",
"re","ana","mal","ante","pre","fore","pro","infra","para",
"inter","ultra","extra","trans","cata","de","oct","octa",
"octo","equi","pseudo","prim","prot","proto","pent","penta",
"quin","quint","quinque","pro","tetr","tetra","quad","quadr",
"quadri","quartet","off","bene","hemi","demi","semi","crypto",
"cent","centi","hecto","en","em","in","im","intro","be",
"macro","poly","mult","multi","neo","nona","novem","ennea",
"in","un","im","il","ir","non","a","nil","paleo","mon","mono",
"uni","e","ex","ec","ef","super","supr","sur","hyper","vic",
"vice","hept","hepta","sept","septe","septem","septi","hex",
"hexa","sex","dis","deca","deka","deci","kilo","mill","milli",
"tri","per","dia","ad","com","di","amphi","bi","bin","bis",
"sub","hypo","epi","eu","holo"};
if(prob(0.65))return "";
return CHOOSE(pref);
}

char *root(env) E env; {
static char *root[] = {
"pan","omni","arch","zo","rog","rogat","cred","flect","flex",
"test","hem","hemato","nasc","nat","bibl","fer","voc","port","lat",
"fortuna","ped","chrom","vinc","vict","crea","cise","mort","mors",
"necr","claim","clam","hetero","pel","puls","vac","iso","phobe",
"phobia","prim","prime","flu","flux","sequ","liber","liver","theo",
"magna","medi","man","manu","pen","pend","pens","eu","capit",
"iatr","aud","aus","cor","cord","cour","grav","ten","tain",
"tent","sacr","sacer","heiro","sanct","cide","mega","ultima",
"ridi","risi","leg","jus","jur","nom","duc","duct","duce",
"bio","viv","vivi","vita","lus","lum","luc","photo",
"min","philo","phile","phila","amic","anthrop","poly","multi",
"fac","fact","fic","fect","meter","psych","mod","mot","mov",
"nov","neo","neg","uni","alter","ali","idio","pop","dem",
"demo","lic","licit","poten","posse","potes","mem","simul",
"arch","homo","mar","mer","vis","vid","scope","auto","mitt",
"miss","ac","acr","brev","clud","clus","dorm","micro","aster",
"astro","rect","recti","forc","fort","path","cap","cep","cept",
"put","tempo","tempor","dent","dont","ver","veri",
"feder","fide","feal","fid","cosm","migra","hydro","aqu",
"endo","gyn","logo","opus","oper","graph","scrib","scrip",
"mis","miso","anni","annu","enni","ced","cede","ceed","cess"};
return CHOOSE(root);
}

prob(f) double f; {return R<f*32767.0;}

char *tense() {return prob(0.5)? "pres": "past";}

char *number() {return prob(0.25)?"plural":"sing";}

X getxx() {
X rv;
static XX empty;
rv=(X)malloc(sizeof*rv);
if(rv==0)printf("outa space\n"),exit(1);
*rv=empty;
return rv;
}

X verbal(env) E env; {
X verbalv=getxx();
int i=0;
verbalv->type="verbal";
if(prob(0.25))verbalv->list.x[i++]=adverb(env);
verbalv->list.x[i++]=verb(env);
return verbalv;
}

X adverb(env) E env; {
static char *wordy[] = {"very ","extremely ","generally ","reasonably ",
		"fundamentally ","essentially ","particularly ","very ",
		"very ","very ",
		"very ","very ",
		"very ","very ",
		"very ","very ",
		"very ","very ",
		"very ","very ",
		"very ","very ",
		"entirely ",
		"rather ","fairly ","relatively ","comparatively ",
		"moderately ",
		"totally ","very ","quite "};
static char *suff[] = {"wardly","ably","wisely","ably","ily","ly","ly","ly"};
static char *c[] = {"absolutely","functionally",
		"accordingly","broadly","actionably","actually",
		"additionally",
		"ambiguously","amply",
		"analogously",
		"aperiodically",
		"apparently","appreciably",
		"appropriately","approximately",
		"arbitrarily",
		"associatively",
		"automatically",
		"awfully",
		"axiomatically",
		"badly","barely","basically",
		"beneficially",
		"blatantly",
		"capably","carefully","carelessly",
		"casually","causally","cautiously",
		"centrally","certainly",
		"cheaply","cleanly",
		"closely","coarsely","cognizantly",
		"coincidentally","collectively","collaterally",
		"comparably",
		"competently","completely","comprehensibly",
		"concededly","conceivably",
		"concisely","conclusively","concretely",
		"concurrently","conjecturally",
		"currently",
		"conscientously","consequently","consequentially",
		"consistently","constantly",
		"contemporaneuosly","constructively",
		"continually","continuously","contractually",
		"contrarily","contributatively","conveniently",
		"conventionally",
		"correctively",
		"correctly",
		"crudely",
		"curiously",
		"decidedly",
		"deeply",
		"deficiently","demandingly",
		"dependably","desireably",
		"determinately","diagnostically",
		"differentially","differently",
		"directly","discernibly",
		"distinctly","doubtfully","dramatically",
		"dynamically",
		"economically",
		"effecaciously","efficiently",
		"elegantly",
		"emphatically","encouragingly",
		"endlessly","endurably",
		"entirely","epistomologically",
		"functionally","immediately",
		"equably","equally","equitably","erroneously",
		"esoterically","eternally","evenly","eventfully",
		"eventually","evidently",
		"exceedingly","exactly","excellently",
		"exceptionally","excessively","exclusively",
		"experimentally",
		"explicitly","extremely",
		"factually","faithfully",
		"faultlessly","feasibly",
		"finitely","firmly","forcefully",
		"formally","formerly","frankly","freely",
		"frugally","fully","generally",
		"globally","gradually",
		"harmlessly",
		"helpfully",
		"highly","homogeneously",
		"hopefully",
		"ideally","identically","ideologically",
		"idiomatically","idiosyncratically","idly",
		"imaginably","immaterially","immensely",
		"impartially","imperceptably","imperfectly","importantly",
		"improperly","imprudently","inaccurately","inappropriately",
		"accurately",
		"inclusively","incompletely","incorrectly",
		"increasingly","independently",
		"indirectly","ineffectively","ineffectually","inefficiently",
		"infallibly","instantaneously","instantly",
		"insufficiently","internally","likely","only",
		"invaluably","inversely","irrelevantly","irrespectively",
		"largely","lastly","legitimately","literally",
		"locally","loosely","manageably","markedly",
		"memorably","mildly","mindfully","moderately",
		"momentarily","naturally","needfully","needlessly",
		"nominally","normally","objectively","occasionally",
		"temporarily",
		"officially","oppositely","ordinarily","ostensibly",
		"partially","permissibly",
		"personally","pertinently",
		"physically","plainly","plainly",
		"pleasingly","politically",
		"potentially","predictively",
		"predominantly","prematurely","preparedly","presently",
		"previously","primarily",
		"primely","principally","problematically",
		"productively","promptly","proportionately",
		"provably","purely","quickly","radically","randomly","recently",
		"repeatedly","secondarily","separately",
		"usually","specifically",
		"redundantly","regardlessly","reliably",
		"remarkably","remotely","respectively",
		"probably",
		"robustly","seemingly",
		"sensibly","singularly","steadily",
		"strikingly","substantially","successfully",
		"supposedly","systematically","understandably",
		"necessarily","unfortunately",
		"unnecessarily","unmistakably","usefully","weakly"};
X adverbv=getxx();
int i=0;
adverbv->type="-adverb";
if(prob(0.150)) {
	adverbv->list.s[i++]=prob(.5)?"simply":"easily";
	return adverbv;
	}
if(prob(0.4))adverbv->list.s[i++]=CHOOSE(wordy);
if(prob(makeup))adverbv->list.s[i++]=CHOOSE(c);
else {
	adverbv->list.s[i++]=prefix(env);
	adverbv->list.s[i++]=root(env);
	adverbv->list.s[i++]=CHOOSE(suff);
	}
return adverbv;
}

X adjective(env) E env; {
static char *suff[] = {"ive","ful","ous","some","oid","ine","esque","en","an",
		"ile","able","ible","istic","ic",
		"an","ian","ish","ite","al","less"};
X adjv=getxx();
int i=0;
adjv->type="-adjective";
if(prob(0.2)) {
	adjv->list.s[i++]="not ";
	adjv->list.s[i++]="un";
	}
if(prob(makeup)) {
	adjv->list.s[i++]=CHOOSE(adjlist);
	return adjv;
	}
adjv->list.s[i++]=prefix(env);
adjv->list.s[i++]=root(env);
adjv->list.s[i++]=CHOOSE(suff);
return adjv;
}

X adjph(env) E env; {
X adjv=getxx();
EE nenv;
static EE empty;
int i=0;
adjv->type="adjph";
if(prob(0.25)) {
	nenv= *env;
	nenv.tense=0;
	adjv->list.x[i++]=rel(&nenv);
	adjv->list.x[i++]=aux(&nenv);
	adjv->list.x[i++]=vp(&nenv);
	return adjv;
	}
nenv=empty;
adjv->list.x[i++]=prep(&nenv);
adjv->list.x[i++]=np(&nenv);
return adjv;
}

X prep(env) E env; {
static char *prep[] = {"across","by","in","of","near","under","over",
		"in back of","below","behind","of","of","of","of",
		"centered around","centered about",
		"in close proximity to","following after",
		"in between","in conflict with","in conjunction with",
		"in the area of","in the neighborhood of","in the proximity of",
		"in the field of","for the purpose of",
		"giving rise to","based upon","being caused by",
		"of","of","of","of",
		"being effectuated by","being aggrevated by",
		"being used with",
		"being collected together with","being combined together with",
		"connected up to","exhibiting a tendency towards",
		"being facilitated by",
		"being employed with",
		"having a deleterious effect upon","impacting",
		"being joined together with","being merged together with",
		"in the vicinity of"};
X pv=getxx();
pv->type="-prep";
pv->list.s[0]=CHOOSE(prep);
return pv;
}

X comp(env) E env; {
X v=getxx();
EE nenv;
static EE empty;
int i=0;
nenv=empty;
v->type="comp";
if(0&&prob(0.001))v->list.x[i++]=adjective(&nenv);
else if(prob(0.1))v->list.x[i++]=advp(&nenv);
else {
	if(env->passive)v->list.x[i++]=passprep(env);
	v->list.x[i++]=np(&nenv);
	env->passive=0;
	}
if(0&&prob(0.05))v->list.x[i++]=adverb(&nenv);
return v;
}

X advp(env) E env; {
X v=getxx();
v->type="advp";
v->list.x[0]=vprep(env);
v->list.x[1]=np(env);
return v;
}

X vprep(env) E env; {
static char *prep[] = {"to","at","by","from","with","for"};
X v=getxx();
v->type="-vprep";
v->list.s[0]=CHOOSE(prep);
return v;
}

E getenvq() {
static EE empty;
E v;
v=(E) malloc(sizeof*v);
if(v==0)printf("outa room\n"),exit(1);
*v=empty;
return v;
}

X comma(env) E env; {
X v=getxx();
static EE empty;
v->type="-comma";
v->list.s[0]=",";
*env=empty;
return v;
}

X conjadv(env) E env; {
static char *c[] = {"therefore","however","moreover","obviously"};
X v=getxx();
v->type="-conjadv";
v->list.s[0]=CHOOSE(c);
return v;
}

X lconjadv(env) E env; {
static char *c[] = {"therefore","however","nevertheless",
		"consequently","also","in addition","moreover",
		"accordingly","essentially","presumably","actually",
		"basically","importantly","clearly","obviously",
		"needless to say","as already stated",
		"generally","approximately","presently",
		"hopefully","usually","in the great majority of cases",
		"seen in the above light","most significantly",
		"when the need arises",
		"in a large number of cases","after this is accomplished",
		"in all cases",
		"having been made aware concerning these matters",
		"as an example of this","as a consequence of this",
		"as a matter of fact","as is often the case",
		"as of this date","assuming that this is the case",
		"at the present moment in time","at this time",
		"as a consequent result of this","as a desireable benefit of this",
		"if at all possible","similarly","in the same connection",
		"in large measure","in many cases","in rare cases",
		"in some cases","in the interim","in the last analysis",
		"in light of these facts","in the majority of instances",
		"in the not too distant future","in the same way as described above",
		"in this case","for all intents and purposes",
		"to arrive at an approximation","for this reason",
		"for many reasons, then",
		"as is often the case","last but not least",
		"later on","on a few occasions","on this occasion",
		"in summary","taking this into consideration",
		"with this in mind",
		"substantially","ultimately"};
X v=getxx();
v->type="-lconjadv";
v->list.s[0]=CHOOSE(c);
return v;
}

X conjsub(env) E env; {
static char *c[] = {"although","even though","despite the fact that",
			"for the simple reason that",
		"because","due to the fact that","since",
		"whether or not",
		"inasmuch as",
		"as"};
X v=getxx();
v->type="-conjsub";
v->list.s[0]=CHOOSE(c);
return v;
}

X lconjsub(env) E env; {
static char *c[] = {"although","even though","despite the fact that",
		"because","due to the fact that","since",
		"if","anytime that","in the case that",
		"as a consequence of the fact that",
		"as regards the fact that",
		"as a desireable benefit of the fact that",
		"with reference to the fact that",
		"as long as",
		"as an important essential of the fact that",
		"in conjunction with the fact that",
		"in the light of the fact that",
		"if","if","if","if",
		"leaving out of consideration the fact that",
		"just as",
		"inasmuch as","until such time as",
		"as soon as","being as","in the same way as",
		"with the exception of the fact that",
		"notwithstanding the fact that",
		"on the grounds that",
		"on the basis of the fact that",
		"persuant to the fact that",
		"although it seems apparent that",
		"with regard to the fact that",
		"as can be seen from the fact that",
		"as"};
X v=getxx();
v->type="-lconjsub";
v->list.s[0]=CHOOSE(c);
return v;
}

X conj(env) E env; {
static char *c[] = {"and","but","yet","and","and"};
X v=getxx();
v->type="-conj";
v->list.s[0]=CHOOSE(c);
return v;
}

X nomz(env) E env; {
static char *c[] = {"it is easy to see that","it is a basic fact that",
		"it is obvious that","it is not unimportant that",
		"it is easy to overlook the fact that",
		"it is within the realm of possibility that",
		"it is apparent that",
		"this is indicitive of the fact that",
		"this is in substantial agreement with the fact that",
		"this demonstrates the fact that",
		"this leaves out of consideration the fact that",
		"it is of the utmost importance that",
		"the truth is that",
		"the fact is that",
		"it turns out that","it will turn out to be true that",
		"it should be noted that",
		"it stands to reason that",
		"it would not be unreasonable to assume that",
		"it is interesting to note that"};
X v=getxx();
v->type="-nomz";
v->list.s[0]=CHOOSE(c);
return v;
}

X turgid(env) E env; {
X v=getxx();
int i=0;
v->type="turgid";
if(prob(T*1.5)) {
	v->list.x[i++]=lconjadv(env);
	v->list.x[i++]=comma(env);
	v->list.x[i++]=sent(env);
	}
else if(prob(2*T)) {
	v->list.x[i++]=turgid(env);
	v->list.x[i++]=comma(env);
	v->list.x[i++]=conj(env);
	v->list.x[i++]=sent(env);
	}
else if(prob(1.5*T)) {
	v->list.x[i++]=lconjsub(env);
	v->list.x[i++]=sent(env);
	v->list.x[i++]=comma(env);
	v->list.x[i++]=sent(env);
	}
else if(prob(T*.5)) {
	v->list.x[i++]=sent(env);
	v->list.x[i++]=comma(env);
	v->list.x[i++]=conjadv(env);
	}
else if (prob(T)) {
	v->list.x[i++]=turgid(env);
	v->list.x[i++]=comma(env);
	v->list.x[i++]=conjsub(env);
	v->list.x[i++]=sent(env);
	}
else if(prob(.5*T)) {
	v->list.x[i++]=nomz(env);
	v->list.x[i++]=sent(env);
	}
else v->list.x[i++]=sent(env);
return v;
}

/**********************************************************/
char buff[1000];
int io;
int flag;
main(ac,av) char *av[]; {
static char *furniture[] = {"WASTEBASKET","ASHTRAY","TABLE",
				"DESK DRAWER","COAT LOCKER","BOOKSHELF"};
static char *ccto[] = {
	"J. J. Argosy",
	"M. D. Banal",
	"H. V. Bandersnatch",
	"F. W. Blivet",
	"Z. Brazen",
	"M. Bushido",
	"J. D. Carbuncle",
	"N. Crab",
	"R. H. deTruckle",
	"C. B. Dudgeon",
	"R. T. Dun",
	"W. G. Fallow",
	"R. S. Flummox",
	"R. N. Fribble",
	"C. R. Glitch",
	"S. A. Hobble",
	"R. S. Limn",
	"S. T. Livid",
	"Mrs. B. R. Mauve",
	"C. H. Russet",
	"M. H. Simper",
	"B. R. Sorrel",
	"G. Swale",
	"R. R. Swarthy",
	"P. Terra-Cotta",
	"U. G. Winnow"};
E env;
X tree;
int i=0;
int j=0;
int k=0;
int lim=25;
long t;
time(&t);
if(ac<2)abo();
if(ac>2) {
	for(makeup=0; *av[2]; av[2]++) {
		if(*av[2]<'0'||*av[2]>'9')abo();
		makeup=makeup*10+*av[2]-'0';
		}
	makeup/=100;
	if(makeup<0||makeup>1)abo();
	makeup=1-makeup;
	}
if(ac>1)for(lim=0; *av[1]; av[1]++) {
		if(*av[1]<'0'||*av[1]>'9')abo();
		lim=lim*10+*av[1]-'0';
		}
srand((int)t);
printf(".TL\n");
env=getenvq();
tree=np(env);
io=0;
pr(tree);
buff[io]=0;
caps();
printf("%s\n",buff);
printf(".AU \"C. C. Festoon\"\n");
printf(".AS\n");
free(env);
do {
	env=getenvq();
	tree=turgid(env);
	io=0;
	pr(tree);
	buff[io]=0;
	printf("%s.\n",buff);
	free(env);
	} while(prob(0.75));
printf(".AE\n");
printf(".MT \"MEMORANDUM FOR %s\"\n",
	CHOOSE(furniture));
while(1) {
if(i>=lim) {
	printf(".SG\n");
	printf(".NS 0\n");
	for(j=0; j==0;) {
		for(i=0; i<sizeof ccto/sizeof *ccto; i++) {
			if(prob(.10))j=1,printf("%s\n",ccto[i]);
			}
		}
	printf(".NE\n");
	exit(0);
	}
if(i++%23==0) {
	env=getenvq();
	tree=np(env);
	io=0;
	printf(".H 1 \"");
	pr(tree);
	buff[io]=0;
	caps();
	printf("%s\"\n",buff);
	free(env);
	}
env=getenvq();
tree=turgid(env);
io=0;
pr(tree);
buff[io]=0;
if(++k%13==0&&prob(0.35)) {
	printf("%s:\n",buff);
	printf(".BL\n");
	do {
		printf(".LI\n");
		free(env);
		env=getenvq();
		io=0;
		tree=sent(env);
		pr(tree);
		buff[io]=0;
		printf("%s.\n",buff);
		} while(prob(.83));
	printf(".LE\n");
	printf(".P\n");
	}
	else printf("%s.\n",buff);
if(++j>2&&prob(0.4))printf(".P\n"),j=0;
free(env);
}
}

pr(tree) X tree; {
int i;
if(flag=='p') {
	out("<");
	out(tree->type);
	out(">");
	}
if(tree->type[0]=='-') {
	out(" ");
	for(i=0; tree->list.s[i]; i++) {
		out(tree->list.s[i]);
		}
	}
else for(i=0; tree->list.x[i]; i++) {
	pr(tree->list.x[i]);
	}
free(tree);
return;
}

out(s)char *s;
{
if(io==0&&*s==' ')return;
if(io==0) {
	for(;s[io]; io++)buff[io]=s[io];
	buff[0]+='A'-'a';
	return;
	}
if(buff[io-1]==' '&&*s==' ')return;
if(buff[io-1]==' '&&*s==',')io--;
if(buff[io-1]=='y'&&*s=='i'&&s[1]=='e')io--;
else if(*s==buff[io-1]&&*s!='s'&&*s!='n')io--;
else if(*s=='e'&&buff[io-1]=='a')io--;
for(; *s; )buff[io++]= *s++;
return;
}

caps()
{int i; for(i=1; i<io; i++)
if(buff[i-1]==' '&&buff[i]<='z'&&buff[i]>='a')buff[i]+='A'-'a';
}
abo(){printf("usage: festoon NUMBER-OF-SENTENCES [percent-invented-nouns]\n");
	exit(1);
	}
