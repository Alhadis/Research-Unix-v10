/*	@(#)unctrl.h	4.1	12/24/82	*/

# include	<stdio.h>
# define	unctrl(ch)	(_unctrl[ch])

extern char	*_unctrl[];
