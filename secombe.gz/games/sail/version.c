version()
{
    static char *cp =
	"Wooden Ships and Iron Men, Version 1.1 (83/03/19)";

    Signal(cp, 0, 0);
    return;
}
