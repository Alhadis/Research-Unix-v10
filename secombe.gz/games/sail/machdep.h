/*
 * sccsid = "@(#)machdep.h	1.8 5/20/83";
 */
#define LOGFILE "/usr/games/lib/saillog"
#define DRIVER "/usr/games/lib/saildriver"
#define DEBUGDRIVER "driver"
#define DRIVERNAME "driver"
#define SAILLOGDEF 0		/* don't look up usernames */
#define SETUID			/* player and driver run setuid */

#define BUFSIZE 2024
