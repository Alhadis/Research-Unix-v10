/*
 * sccsid = "@(#)player.h	1.1 3/17/83";
 */
#include <curses.h>
#include "externs.h"

#define ROWSINVIEW 15
#define COLSINVIEW 75

extern WINDOW *view;
extern WINDOW *slot;

