static char junk[] = "\n@(#)LIBF77 VERSION 2.00  11 JUNE 1980\n";

/*
2.00	11 June 1980.  File version.c added to library.
*/
