typedef	unsigned short	ushort;
typedef	unsigned char	uchar;
typedef unsigned long	ulong;
typedef		long	vlong;
#define	Length	long hlenght; long length
