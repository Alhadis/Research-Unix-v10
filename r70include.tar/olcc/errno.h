#ifndef __ERRNO
#define __ERRNO
 
#include "/usr/include/errno.h"

extern int	errno;
extern char*	sys_errlist[];
extern int	sys_nerr;

#endif
