// This file defines things that are convenient for people
// who want to cope simultaneously with several different cfronts.

#ifndef __const

#define __const const

#define externC extern "C"

#endif
