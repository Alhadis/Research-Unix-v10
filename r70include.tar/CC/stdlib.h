#ifndef __STDLIB_H
#define __STDLIB_H 1

#include <libc.h>

#endif
