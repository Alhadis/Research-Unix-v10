extern "C" {
	extern void* memccpy(void*, const void*, int, size_t);
	extern void* memchr(const void*, int, size_t);
	extern int memcmp(const void*, const void*, size_t);
	extern void* memcpy(void*, const void*, size_t);
	extern void* memset(void*, int, size_t);
	extern void* memmove(void*, const void*, size_t);
}
