#ifndef __OSFCN_H
#define __OSFCN_H 1

#include <sysent.h>

extern int open(const char*, int, int);		// System V simulator

#endif
