/*ident	"@(#)ctrans:lib/stream/ios.h	1.1.1.1" */
/**************************************************************************
			Copyright (c) 1984 AT&T
	  		  All Rights Reserved  	

	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T
	
	The copyright notice above does not evidence any   	
	actual or intended publication of such source code.

ios.h:

*****************************************************************************/

// information needed by iostreams, but not publicly.
