#define	P_tmpdir	"/tmp/"
#define	L_tmpnam	(sizeof(P_tmpdir) + 15)
