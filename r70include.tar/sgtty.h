/*
 * compatibility hack
 */
#include <sys/ttyio.h>
