/*	udp_var.h	6.1	83/07/29	*/

/*
 * UDP kernel structures and variables.
 */
struct	udpiphdr {
	struct 	ipovly ui_i;		/* overlaid ip structure */
	struct	udphdr ui_u;		/* udp header */
};
#define	ui_next		ui_i.ih_next
#define	ui_bp		ui_i.ih_bp
#define	ui_x1		ui_i.ih_x1
#define	ui_pr		ui_i.ih_pr
#define	ui_len		ui_i.ih_len
#define	ui_src		ui_i.ih_src
#define	ui_dst		ui_i.ih_dst
#define	ui_sport	ui_u.uh_sport
#define	ui_dport	ui_u.uh_dport
#define	ui_ulen		ui_u.uh_ulen
#define	ui_sum		ui_u.uh_sum

struct	udpstat {
	int	udps_hdrops;
	int	udps_badsum;
	int	udps_badlen;
	int	udps_badport;
	int	udps_inqfull;
	int	udps_ipackets;
};

#ifdef KERNEL
/*
struct	inpcb udb;
*/
struct	udpstat udpstat;
#endif

/* sizeof largest udp message (at ip level) */
#define UDP_MSG_LIMIT (UDP_BODY_LIMIT+sizeof(struct udpiphdr))
