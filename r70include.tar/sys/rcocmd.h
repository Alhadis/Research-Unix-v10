#define RCORES		(('R'<<8)|1)
#define RCODITHER	(('R'<<8)|2)
#define RCOHACK		(('R'<<8)|3)		/* obsolete ? */

#define IOSIZE		(1069200)
#define IOALIGN		(4*512)
