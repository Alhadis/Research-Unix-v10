struct bufld {
	struct	queue *queue;
	u_char	rnchar;
	u_char	btime;
	u_char	nchar;
	u_char	nclick;
	u_char	index;
};
