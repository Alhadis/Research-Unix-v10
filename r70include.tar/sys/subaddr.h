/*
 * subdevice addressing
 */

struct subaddr {
	short ctl;	/* controller number */
	short unit;	/* unit number */
};
