struct vplot {
	int	open;
	struct device *addr;
	struct buf buf;
};
