/*
 * #include <sys/vm.h>
 * is a quick way to include all the vm header files.
 */
#include <sys/vmparam.h>
#include <sys/vmmac.h>
#include <sys/vmmeter.h>
#include <sys/vmsystm.h>
