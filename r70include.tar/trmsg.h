#define	Tblock	0200
#define	Tmove	0201
#define	Trelease 0202
#define	Tmark	0203
#define	Tflush	0204
#define	Trxint	0205
#define	Topen	0206
#define	Tclose	0207
#define	Tsleep	0210
#define	Twrite	0211
#define	Tbwrite	0212
#define	Tbwait	0213
#define	Tread	0220
#define	Trend	0221
#define	Tsmeta	0222
#define	Tablock	0223
#define	Tbusy	0224
#define	Trxmeta 0225
#define Tlive	0226
#define	Tbread	0227
#define	Trxmit	0230
#define	Trzero	0231
#define	Trproc	0232
#define	Tdowrite 0233
#define	Tgetblk	0234
#define	Tbrelse	0235

#define	TSIZE	250
#define	Tdkxin	240
#define	Tdkxou	241
#define	Tdkrin	242
#define	Tdkrou	243
#define	Tdkrb	244
#define	Tdkstart 245
#define	Tdkmark 246
#define	Tdkrmark 247


