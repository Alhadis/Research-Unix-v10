#define	VAX
#define	VMUNIX

#define	SYSTEM	"/vmunix"
