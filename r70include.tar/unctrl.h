extern char	*_unctrl[];

# define	unctrl(ch)	(_unctrl[ch])
